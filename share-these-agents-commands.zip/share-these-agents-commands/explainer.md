# Claude Code Agents & Commands

This collection contains agents and commands for Claude Code that implement a structured workflow for software development. The system uses specialized agents that work together to investigate, plan, implement, test, and document code changes.

---

## Workflow Overview

### 3-Agent Workflow (Recommended for most tasks)
```
Scout-and-Plan → Build → Test-and-Cleanup
```
Faster, fewer handoffs. Best for simpler projects and faster iteration.

### 5-Agent Workflow (Detailed audit trail)
```
Scout → Plan → Build → Test → Cleanup
```
More thorough with separate investigation and planning phases. Best for complex projects requiring detailed documentation.

---

## Agents (`agents/`)

### Investigation & Planning

| Agent | Purpose |
|-------|---------|
| **scout.md** | Investigates codebase, identifies affected files, traces call chains, and assesses complexity before implementation begins. Includes Ripple Effect Analysis to prevent scope underestimation. |
| **scout-and-plan.md** | Combined investigation + planning agent. Analyzes the request, explores the codebase, and creates a detailed implementation plan in one pass. |
| **plan.md** | Standalone planning agent that transforms Scout findings into detailed implementation plans with subtasks, validation commands, and completion criteria. |

### Implementation

| Agent | Purpose |
|-------|---------|
| **build.md** | Executes the implementation plan subtask-by-subtask. Creates/modifies files, runs validation commands, and tracks progress. Includes database safety protocols. |

### Validation & Documentation

| Agent | Purpose |
|-------|---------|
| **test.md** | Validates Build agent's work through unit tests, integration tests, and E2E/Playwright testing. Runs pre-flight checks and enforces zero-warnings policy. |
| **test-and-cleanup.md** | Combined validation + finalization agent. Runs tests, fixes issues, creates completion reports, tracks deferred work, and commits changes. |
| **cleanup.md** | Standalone cleanup agent that documents accomplishments, verifies deferred work is tracked, creates completion reports, and handles git commit/push. |

### Debugging & Issue Management

| Agent | Purpose |
|-------|---------|
| **debug.md** | Systematic debugging methodology for investigating issues. Uses structured investigation areas and documents findings. |
| **task-shard.md** | Breaks down large GitHub issues into smaller, manageable sub-issues. Analyzes scope, creates ordered subtasks, and links them to the parent issue. |

---

## Commands (`commands/`)

### Issue Creation

| Command | Purpose |
|---------|---------|
| **bug.md** | Creates GitHub bug issues with intelligent input parsing. Includes templates for error details, reproduction steps, and investigation notes. |
| **feature.md** | Creates comprehensive GitHub feature issues with user stories, requirements, technical context, and acceptance criteria. |

### Workflow Orchestration

| Command | Purpose |
|---------|---------|
| **orchestrate3.md** | Executes the 3-agent workflow (Scout-and-Plan → Build → Test-and-Cleanup). Coordinates agents, tracks timing, and produces final reports. |
| **orchestrate5.md** | Executes the 5-agent workflow with full separation of concerns. Includes database safety protocols with pre/post workflow backup and verification. |
| **orchestrate.md** | Most robust orchestration command with 7-layer database protection, pre-workflow backup, test database reseed, and post-workflow health checks. |

### Batch Processing

| Command | Purpose |
|---------|---------|
| **orchestrate3-all.md** | Batch processing for multiple issues using the 3-agent workflow. |
| **orchestrate5-all.md** | Batch processing for multiple issues using the 5-agent workflow. |

### Issue Analysis

| Command | Purpose |
|---------|---------|
| **analyze-issue-completion.md** | Deep investigation of GitHub issues to determine completion status. Creates analysis reports and takes appropriate actions (close, create follow-ups, decompose). |

---

## Key Features

### Database Safety Protocol
Several agents include database safety measures:
- All operations target test environment only
- Production database is never modified
- Pre-workflow backups preserve state
- Post-workflow verification ensures integrity

### Ripple Effect Analysis
Scout agents trace full call chains to identify ALL affected files before implementation, preventing scope underestimation.

### Zero Warnings Policy
Test agents enforce fixing ALL warnings (ESLint, TypeScript, build) before completion, including pre-existing warnings.

### Lessons Learned Tracking
Cleanup agents include sections for documenting what went well, what could be improved, and process improvements for future work.

### Verification Checkpoints
Issue templates include verification checkpoints to confirm file paths exist and patterns are still valid before starting work.

---

## Installation

1. Copy the `agents/` folder to `.claude/agents/` in your project
2. Copy the `commands/` folder to `.claude/commands/` in your project
3. Update project-specific paths and configurations in each file
4. Create output directories: `.agents/outputs/`, `.agents/timing/`, `completion-docs/`

---

## Customization Notes

Before using these agents, update:
- **Project paths**: Replace absolute paths with your project root
- **Tech stack references**: Adjust for your framework (Next.js, Laravel, etc.)
- **Database configuration**: Update ports, credentials, and safety protocols
- **Output locations**: Configure where reports and timing data are stored
- **Testing commands**: Match your test runner (Jest, Vitest, PHPUnit, etc.)

---

## Usage Examples

```bash
# Create a bug issue
/bug Users cannot submit form - validation error

# Create a feature issue
/feature Add export to CSV functionality

# Execute 3-agent workflow on GitHub issue
/orchestrate3 gh issue #17

# Execute 5-agent workflow with database protection
/orchestrate5 #42

# Analyze and close completed issues
/analyze-issue-completion 299 303 304

# Break down a large issue into subtasks
# Use the task-shard agent via Task tool
```

---

## File Naming Conventions

Agent outputs follow this pattern:
- Scout: `scout-[ISSUE]-[MMDDYY].md`
- Plan: `plan-[ISSUE]-[MMDDYY].md`
- Build: `build-[ISSUE]-[MMDDYY].md`
- Test: `test-[ISSUE]-[MMDDYY].md`
- Cleanup: `cleanup-[ISSUE]-[MMDDYY].md`

Completion reports: `YYYY-MM-DD-issue-XXX-description.md`
