---
command: "/orchestrate"
category: "Project Orchestration"
purpose: "Execute complete 5-agent workflow (Scout → Plan → Build → Test → Cleanup)"
---

# Orchestrate Command - 5-Agent Workflow

Execute the complete 5-agent workflow for implementing features, fixing bugs, or completing chores. This command orchestrates all agents sequentially without doing any work itself.

## 🚨 CRITICAL: PRODUCTION DATABASE PROTECTION 🚨

**THIS WORKFLOW ONLY OPERATES ON TEST ENVIRONMENT (PORT 7171)**

- ✅ **Target**: Test database (`entertask_test` on port 7171)
- ✅ **Containers**: `app-test`, `nginx-test` only
- ❌ **Production**: Port 8080 database (`entertask`) is **NEVER** modified
- ❌ **Production**: If you see empty database at port 8080, STOP - this is a critical error

**If production database becomes empty:**
1. STOP all work immediately
2. Report to user
3. Do NOT proceed with commit/push
4. Production must be restored from backups

**All 5 agents (Scout → Plan → Build → Test → Cleanup) include strict environment verification. If any agent targets production, it's a bug.**

## ⚠️ CRITICAL: ORCHESTRATION ONLY ⚠️

**WHEN THE USER TYPES `/orchestrate`, YOU ARE A CONDUCTOR, NOT A PERFORMER.**

**YOU MUST:**
- ✅ Call agents directly
- ✅ Report agent progress to user
- ✅ Read agent outputs
- ✅ Summarize results
- ✅ Coordinate workflow

**YOU MUST NEVER:**
- ❌ Read code files yourself
- ❌ Write or edit any code
- ❌ Run tests directly
- ❌ Create or modify files
- ❌ Execute bash commands (except via agents)
- ❌ Investigate bugs yourself
- ❌ Do ANY implementation work

**IF YOU CATCH YOURSELF USING Read, Write, Edit, Grep, Glob, or Bash tools directly during `/orchestrate`, YOU ARE DOING IT WRONG. STOP IMMEDIATELY AND DELEGATE TO AN AGENT.**

Your ONLY job is to call agents via the Task tool and report their results. Nothing more.

## Usage

```
/orchestrate [input]
```

**Input can be:**
- Plain text description: `/orchestrate Add dark mode toggle to settings`
- Spec file reference: `/orchestrate @specs/feature-client-codes-crud.md`
- Github issue: `/orchestrate gh issue #17`
- Bug description: `/orchestrate Fix null pointer in expense report controller`
- Multiple items: `/orchestrate Implement OAuth2 + Add user management + Create admin dashboard`

## Workflow Process

### Input Parsing: Extract Issue Number

**Purpose**: Extract GitHub issue number for backup naming and tracking

**Your Role**:
1. Parse user input for issue number patterns:
   - GitHub URL: `https://github.com/entertask/entertask/issues/160` → Extract `160`
   - Issue reference: `/orchestrate #160` → Extract `160`
   - Issue command: `/orchestrate gh issue #160` → Extract `160`
   - Plain text: `/orchestrate Add dark mode` → No issue number (use timestamp)

2. Set ISSUE_NUMBER variable:
   ```bash
   # If issue number found:
   ISSUE_NUMBER=160

   # If no issue number:
   ISSUE_NUMBER=$(date +%s)  # Unix timestamp as fallback
   ```

3. Report to user:
   - If GitHub issue: "📋 Processing GitHub Issue #160"
   - If no issue: "📋 Processing ad-hoc task (backup ID: 1729531200)"

### Pre-Workflow: Initialize Timing Metrics

**Purpose**: Track actual execution time for each agent to identify bottlenecks

**Your Role**:
1. Create timing file for this workflow:
   ```bash
   TIMING_FILE=".agents/timing/issue-${ISSUE_NUMBER}-timing.json"
   mkdir -p .agents/timing
   # Use portable timestamp format (macOS compatible)
   WORKFLOW_START=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")

   # Initialize proper JSON structure
   cat > $TIMING_FILE << EOF
{
  "issue": "$ISSUE_NUMBER",
  "workflow_start": "$WORKFLOW_START"
}
EOF
   ```

2. Report to user: "⏱️ Timing metrics initialized for Issue #$ISSUE_NUMBER"

### Pre-Workflow: Database Backup (CRITICAL)

**Purpose**: Preserve current database state before executing any agent workflow

**Your Role**:
1. Report to user: "💾 Creating database backup..."

2. Execute backup script:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask/laravel
   bash ../scripts/backup-clean-state.sh ../.backups
   ```

3. Verify backup completed successfully (check exit code and output)

4. Report to user:
   ```
   ✅ Database backup complete
      Location: .backups/postgres_clean_state_[timestamp].sql
      Target: Production database (entertask)
      Purpose: Recovery point if agents encounter errors
   ```

5. **If GitHub issue**: Post comment confirming backup:
   - Command: `gh issue comment $ISSUE_NUMBER --body "💾 **Pre-Workflow Backup Complete** - Database backed up successfully. Safe to proceed with 5-agent workflow."`

**Backup Details**:
- Location: `./.backups/postgres_clean_state_[timestamp].sql`
- Size: Depends on current data
- Rotation: Keeps max 5 backups (oldest deleted automatically)
- Idempotent: Safe to create multiple backups
- Purpose: Recovery point if agents encounter critical errors

**Safety Rule**: If backup fails, STOP and report error to user. Do NOT proceed with agent workflow.

### Pre-Workflow: Test Database Reseed (CRITICAL)

**Purpose**: Ensure test environment (port 7171) has known-good state with complete test data AND synchronized schema/migrations from production.

**Why This Matters**:
- Scout/Plan/Build/Test agents all rely on test database having contracts, users, expenses
- **Schema Sync**: Test database must have same schema/migrations as production to catch issues
- Without reseed, test database may be in unknown state (partially populated, migrations incomplete)
- Ensures browser testing on port 7171 works (test users available, test data present)
- Prevents false positives from incomplete testing (e.g., "contracts don't exist" vs "code is broken")

**Your Role**:
1. Report to user: "🔄 Reseeding test database (force restore to sync schema)..."

2. Execute reseed script **WITH --force flag**:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   bash ./scripts/reseed-test-database.sh --force
   ```

   **IMPORTANT**: The `--force` flag ensures a full restore from the production backup, which:
   - Syncs all schema changes and migrations from production
   - Ensures test database matches production structure
   - Prevents "works on test, fails on prod" issues

3. Verify reseed completed successfully (check exit code and final success message)

4. Report to user:
   ```
   ✅ Test database reseed complete (force restore)
      Database: entertask_test (port 7171)
      Data: 28,110 expense reports, 532 contracts, 606 employees, 441 users
      Test Users: 6 role-based accounts (admin@test.com, hr@test.com, etc.)
      OAuth2: 6 VTM Group tenants seeded
      Schema: Synchronized with production backup
      Purpose: Scout/Plan/Build/Test agents can now run with complete test data
   ```

5. **If GitHub issue**: Post comment confirming reseed:
   - Command: `gh issue comment $ISSUE_NUMBER --body "🔄 **Test Database Reseed Complete** - Test environment force-restored with complete data, test users, and synchronized schema. Proceeding with Scout investigation."`

**Reseed Details**:
- Location: `./scripts/reseed-test-database.sh`
- Duration: ~2-3 minutes (force restore takes full time)
- Scope: Entire entertask_test database
- Safety: Only affects port 7171 test environment, never touches production (port 8080)
- `--force` flag: Ensures full restore even if database appears populated (syncs schema)
- Without `--force`: Would skip restore if database has >27,000 records (for subsequent runs)

**Safety Rule**: If reseed fails, STOP and report error to user. Do NOT proceed with agent workflow (test data is critical for testing).

### Phase 1: Scout Agent

**Purpose**: Investigation and analysis

**Your Role**:
1. Return to project root directory:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   ```

2. Capture start timestamp:
   ```bash
   SCOUT_START=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Scout Agent starting at $SCOUT_START"
   ```

3. Call Scout agent directly
4. Pass input exactly as provided by user
5. Report: "🔍 Scout Agent starting..."
6. Wait for Scout agent to complete
7. **Extract AGENT_RETURN**: Scout will end with `AGENT_RETURN: scout-[ISSUE_NUMBER]-[MMDDYY]` - save this filename

8. Capture end timestamp and save:
   ```bash
   SCOUT_END=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Scout Agent completed at $SCOUT_END"

   # Update timing file with proper JSON
   python3 -c "
import json
with open('$TIMING_FILE', 'r') as f:
    data = json.load(f)
data['scout_start'] = '$SCOUT_START'
data['scout_end'] = '$SCOUT_END'
with open('$TIMING_FILE', 'w') as f:
    json.dump(data, f, indent=2)
"
   ```

9. Report: "✅ Scout Agent complete"
10. **If GitHub issue**: Post comment with brief summary and filename
   - Example: "🔍 **Scout Phase Complete** - Issue is a feature request to add user authentication. Current system uses OAuth2, needs to be integrated with Azure AD. Output: `scout-180-102325.md`"
   - Command: `gh issue comment $ISSUE_NUM --body "🔍 **Scout Phase Complete** - [2-3 sentence summary] Output: \`[SCOUT_FILENAME_FROM_AGENT_RETURN]\`"`

**Scout Task**:
```
Task({
  subagent_type: "scout",
  description: "Scout phase - investigation",
  prompt: `**Input**: [pass user's input here]

**Instructions**:
Follow your Scout Agent instructions to investigate and analyze this request.

**Success**: Scout output file created with complete investigation`
})
```

### Phase 2: Plan Agent

**Purpose**: Create detailed implementation plan

**Your Role**:
1. Return to project root directory:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   ```

2. Capture start timestamp:
   ```bash
   PLAN_START=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Plan Agent starting at $PLAN_START"
   ```

3. Use Scout's AGENT_RETURN filename (from Phase 1)
4. Call Plan agent via Task tool
5. Report: "📋 Plan Agent starting..."
6. Wait for Plan agent to complete
7. **Extract AGENT_RETURN**: Plan will end with `AGENT_RETURN: plan-[ISSUE_NUMBER]-[MMDDYY]` - save this filename

8. Capture end timestamp and save:
   ```bash
   PLAN_END=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Plan Agent completed at $PLAN_END"

   # Update timing file with proper JSON
   python3 -c "
import json
with open('$TIMING_FILE', 'r') as f:
    data = json.load(f)
data['plan_start'] = '$PLAN_START'
data['plan_end'] = '$PLAN_END'
with open('$TIMING_FILE', 'w') as f:
    json.dump(data, f, indent=2)
"
   ```

9. Report: "✅ Plan Agent complete"
10. **If GitHub issue**: Post comment with brief summary and filename
   - Example: "📋 **Plan Phase Complete** - 5 tasks identified (3-4 hours estimated). Key changes: Update User model, add OAuth2 routes, create login form, add unit tests. Output: `plan-180-102325.md`"
   - Command: `gh issue comment $ISSUE_NUM --body "📋 **Plan Phase Complete** - [X tasks, Y hours estimated]. Key changes: [list] Output: \`[PLAN_FILENAME_FROM_AGENT_RETURN]\`"`

**Plan Task**:
```
Task({
  subagent_type: "plan",
  description: "Plan phase - implementation plan",
  prompt: `**Input**: Read the Scout agent's output file: .agents/outputs/[SCOUT_FILENAME_FROM_AGENT_RETURN]

**Instructions**:
Follow your Plan Agent instructions to create detailed implementation plan.

**Success**: Plan output file created with complete implementation roadmap`
})
```

### Phase 3: Build Agent

**Purpose**: Execute implementation

**Your Role**:
1. Return to project root directory:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   ```

2. Capture start timestamp:
   ```bash
   BUILD_START=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Build Agent starting at $BUILD_START"
   ```

3. Use Plan's AGENT_RETURN filename (from Phase 2)
4. Call Build agent via Task tool
5. Report: "🔨 Build Agent starting..."
6. Wait for Build agent to complete
7. **Extract AGENT_RETURN**: Build will end with `AGENT_RETURN: build-[ISSUE_NUMBER]-[MMDDYY]` - save this filename

8. Capture end timestamp and save:
   ```bash
   BUILD_END=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Build Agent completed at $BUILD_END"

   # Update timing file with proper JSON
   python3 -c "
import json
with open('$TIMING_FILE', 'r') as f:
    data = json.load(f)
data['build_start'] = '$BUILD_START'
data['build_end'] = '$BUILD_END'
with open('$TIMING_FILE', 'w') as f:
    json.dump(data, f, indent=2)
"
   ```

9. Report: "✅ Build Agent complete"
10. **If GitHub issue**: Post comment with brief summary and filename
   - Example: "🔨 **Build Phase Complete** - All 5 tasks implemented. Created: User model, OAuth2 controller. Modified: routes, login component. Build status: ✅ Passing. Output: `build-180-102325.md`"
   - Command: `gh issue comment $ISSUE_NUM --body "🔨 **Build Phase Complete** - [files created/modified]. Build status: [✅/❌] Output: \`[BUILD_FILENAME_FROM_AGENT_RETURN]\`"`

**Build Task**:
```
Task({
  subagent_type: "build",
  description: "Build phase - implementation",
  prompt: `**Input**: Read the Plan agent's output file: .agents/outputs/[PLAN_FILENAME_FROM_AGENT_RETURN]

**Instructions**:
Follow your Build Agent instructions to execute implementation.
Execute subtasks in order, validate each subtask, fix all warnings.

**Success**: All code created, build output file complete, ready for testing`
})
```

### Phase 4: Test Agent

**Purpose**: Validate and fix issues

**Your Role**:
1. Return to project root directory:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   ```

2. Capture start timestamp:
   ```bash
   TEST_START=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Test Agent starting at $TEST_START"
   ```

3. Use Build's AGENT_RETURN filename (from Phase 3)
4. Call Test agent via Task tool
5. Report: "🧪 Test Agent starting..."
6. Wait for Test agent to complete
7. **Extract AGENT_RETURN**: Test will end with `AGENT_RETURN: test-[ISSUE_NUMBER]-[MMDDYY]` - save this filename

8. Capture end timestamp and save:
   ```bash
   TEST_END=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Test Agent completed at $TEST_END"

   # Update timing file with proper JSON
   python3 -c "
import json
with open('$TIMING_FILE', 'r') as f:
    data = json.load(f)
data['test_start'] = '$TEST_START'
data['test_end'] = '$TEST_END'
with open('$TIMING_FILE', 'w') as f:
    json.dump(data, f, indent=2)
"
   ```

9. Report: "✅ Test Agent complete"
10. **If GitHub issue**: Post comment with brief summary and filename
   - Example: "🧪 **Test Phase Complete** - All tests passing (48/48). Coverage: 92%. Fixed 2 edge cases in OAuth2 token refresh. Ready for production. Output: `test-180-102325.md`"
   - Command: `gh issue comment $ISSUE_NUM --body "🧪 **Test Phase Complete** - [X/X tests passing]. Coverage: [Y%]. [Fixes made]. Output: \`[TEST_FILENAME_FROM_AGENT_RETURN]\`"`

**Test Task**:
```
Task({
  subagent_type: "test",
  description: "Test phase - validation",
  prompt: `**Inputs**:
- Build agent's output file: .agents/outputs/[BUILD_FILENAME_FROM_AGENT_RETURN]
- Plan agent's output file: .agents/outputs/[PLAN_FILENAME_FROM_AGENT_RETURN]

**Instructions**:
Follow your Test Agent instructions to validate and fix issues.
Resolve blockers first, create unit tests, run automated validation.

**Success**: All tests passing, test output file complete, ready for cleanup`
})
```

### Phase 5: Cleanup Agent

**Purpose**: Document completion, detect future work, finalize

**Your Role**:
1. Return to project root directory:
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   ```

2. Capture start timestamp:
   ```bash
   CLEANUP_START=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
   echo "⏱️ Cleanup Agent starting at $CLEANUP_START"
   ```

3. Use Scout's AGENT_RETURN filename (from Phase 1)
4. Use Plan's AGENT_RETURN filename (from Phase 2)
5. Use Build's AGENT_RETURN filename (from Phase 3)
6. Use Test's AGENT_RETURN filename (from Phase 4)
7. Call Cleanup agent via Task tool
8. Report: "🧹 Cleanup Agent starting..."
9. Wait for Cleanup agent to complete
10. **Extract AGENT_RETURN**: Cleanup will end with `AGENT_RETURN: cleanup-[ISSUE_NUMBER]-[MMDDYY]` - save this filename

11. Capture end timestamp and complete timing file:
    ```bash
    CLEANUP_END=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
    WORKFLOW_END=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")
    echo "⏱️ Cleanup Agent completed at $CLEANUP_END"

    # Update timing file with final timestamps
    python3 -c "
import json
with open('$TIMING_FILE', 'r') as f:
    data = json.load(f)
data['cleanup_start'] = '$CLEANUP_START'
data['cleanup_end'] = '$CLEANUP_END'
data['workflow_end'] = '$WORKFLOW_END'
with open('$TIMING_FILE', 'w') as f:
    json.dump(data, f, indent=2)
"

    # Report timing summary
    echo "📊 Timing metrics saved to $TIMING_FILE"
    ```

12. Report: "✅ Cleanup Agent complete"
13. **If GitHub issue**: Post comment with brief summary and filename
    - Example: "🧹 **Cleanup Phase Complete** - Work committed and pushed. Completion report: completion-docs/2025-10-17-add-user-auth.md. Future work detected: Mobile OAuth2 support (create issue #42). Output: `cleanup-180-102325.md`"
    - Command: `gh issue comment $ISSUE_NUM --body "🧹 **Cleanup Phase Complete** - Commit: [hash]. Report: [location]. Future work: [detected issues or none]. Output: \`[CLEANUP_FILENAME_FROM_AGENT_RETURN]\`"`

**Cleanup Task**:
```
Task({
  subagent_type: "cleanup",
  description: "Cleanup phase - finalization",
  prompt: `**Inputs**:
- Scout agent's output file: .agents/outputs/[SCOUT_FILENAME_FROM_AGENT_RETURN]
- Plan agent's output file: .agents/outputs/[PLAN_FILENAME_FROM_AGENT_RETURN]
- Build agent's output file: .agents/outputs/[BUILD_FILENAME_FROM_AGENT_RETURN]
- Test agent's output file: .agents/outputs/[TEST_FILENAME_FROM_AGENT_RETURN]
- **Timing data file**: .agents/timing/issue-[ISSUE_NUMBER]-timing.json
[If spec file: - Original spec file path: [spec-path]]
[If GitHub issue: - GitHub issue number: #[number]]

**Instructions**:
Follow your Cleanup Agent instructions to finalize workflow.

**IMPORTANT - Include Timing Metrics**:
Read the timing JSON file and include performance metrics in your completion report.
Calculate duration for each agent and total workflow time.
Include a timing summary section showing which agents took longest.

MANDATORY: Run database restoration and OAuth2 verification.
Detect future work needs, create specs for significant issues (>4 hours).
Create completion report in completion-docs/.
[If spec file: Update spec file with build results and move to specs/tested/]
[If GitHub issue: Update issue with results and close if appropriate]
Git commit and push.

**Success**: Workflow documented with timing metrics, future work specs created, git committed, cleanup output file complete`
})
```

### Post-Workflow: Database Health Check (OPTIONAL VERIFICATION)

**✨ NEW (Nov 2025)**: Production database now protected with 7-layer safety strategy. Automatic restoration removed to prevent data loss.

**⚠️ OPTIONAL STEP**: After Cleanup agent completes, you MAY verify production database health, but restoration should NOT run automatically.

**Your Role**:
1. Report to user: "💾 Verifying production database health..."

2. Execute verification script (read-only check):
   ```bash
   cd /Users/paulbrown/Desktop/coding-projects/entertask
   ./scripts/verify-production-safety.sh
   ```

3. **Script behavior** (8 read-only safety checks):
   - ✅ Docker environment running
   - ✅ Database has >= 27,000 expense records
   - ✅ Recent backup exists (<24 hours old)
   - ✅ Backup file size valid (20-50MB)
   - ✅ Docker volume exists
   - ✅ No test connections to production
   - ✅ Active connection count acceptable
   - ✅ Canary table healthy (if configured)

4. **If verification passes** (exit code 0):
   - Report to user:
     ```
     ✅ Production database health check passed
        Status: All 8 safety checks passed
        Database: 28,104+ expense records
     ```
   - **If GitHub issue**: Post comment: `gh issue comment $ISSUE_NUMBER --body "✅ **Post-Workflow Database Health Check** - Production database verified healthy (28,104+ records, recent backup available)."`
   - Proceed to Phase 6 (Final Report)

5. **If verification fails** (exit code 1):
   - Report to user:
     ```
     ⚠️ WARNING: Production database health check failed
        One or more safety checks failed
        Check verify-production-safety.sh output above

     This does NOT indicate a problem with the workflow.
     The workflow only modifies TEST database (port 7171).

     Production database may need manual attention.
     ```
   - **Still proceed to Phase 6** (this is just a health check)
   - **If GitHub issue**: Post comment with warning

**🚨 IMPORTANT - Database Targeting**:
- **All 5 agents**: Scout, Plan, Build, Test, Cleanup work EXCLUSIVELY on TEST database (port 7171)
- **Test database**: `entertask_test` on `db-test` container (port 5171 internal, 7171 external)
- **Production database**: `entertask` on `db` container (port 5080 internal, 8080 external)
- **Agents NEVER touch production** - they use test environment only

**Why Verification Only (No Automatic Restore)**:
- ✅ Production database now has 7-layer protection strategy (see `/docs/database/PROTECTION-STRATEGY.md`)
- ✅ Improved `restore-clean-state.sh` v2.0 with safety checks (skips if DB already complete)
- ✅ Volume snapshots for 30-second rollback
- ✅ Audit trail logging (`.logs/database-operations.log`)
- ❌ **Do NOT run restore automatically** - caused data loss incident (Nov 2025)
- ✅ Only restore if user explicitly requests it

**If Production Database Actually Needs Restoration** (rare):
User should manually run:
```bash
cd /Users/paulbrown/Desktop/coding-projects/entertask
./scripts/restore-clean-state.sh  # Script will check and skip if DB already complete
```

**Protection Documentation**:
- Strategy: `/docs/database/PROTECTION-STRATEGY.md`
- Credentials: `/docs/database/DATABASE-CREDENTIALS.md`
- Quick Start: `/docs/database/README.md`

### Phase 6: Final Report

**Your Role**:
1. Read cleanup-output.md
2. Read timing metrics from $TIMING_FILE (if available)
3. Report to user:

```markdown
# 5-Agent Workflow Complete

## Status
✅ Scout → ✅ Plan → ✅ Build → ✅ Test → ✅ Cleanup

## ⏱️ Performance Metrics
[If timing data available, show duration for each agent and total time]
- **Total Duration**: [calculated from workflow_start to workflow_end]
- **Scout**: [duration] ([percentage]%)
- **Plan**: [duration] ([percentage]%)
- **Build**: [duration] ([percentage]%)
- **Test**: [duration] ([percentage]%)
- **Cleanup**: [duration] ([percentage]%)

**Bottleneck**: [Agent with highest percentage]
**Efficiency**: [Compare to historical average if available]

## What Was Accomplished
[From cleanup-output.md: summary]

## Files Changed
- Created: [count]
- Modified: [count]

## Testing
- PHPUnit: [X/X tests passed]
- TypeScript Build: [✅/❌]
- Playwright: [results]

## Documentation
- Completion Report: `completion-docs/[YYYY-MM-DD]-[name].md`
- Timing Data: `.agents/timing/issue-[ISSUE_NUMBER]-timing.json`
[If spec file: - Spec Tested: `specs/tested/[spec-name].md`]

## Future Work Detected
[If any specs created, list them]

## Git Status
- Commit: [hash]
- Pushed: ✅

## Next Steps
1. Review completion report
2. Test OAuth2 login at http://localhost:8080
3. Review future work specs (if any)
4. Decide on next task

**Workflow Complete - Awaiting Your Review**
```

## Special Cases

### Spec File Input

If user provides a spec file (e.g., `@specs/feature-name.md`):

1. **Pass spec path to Scout**: Scout reads spec file for context
2. **Pass spec path to Cleanup**: Cleanup updates spec with build results
3. **Cleanup moves spec**: From `specs/` to `specs/tested/`
4. **Report in final output**: Note which spec was tested

### GitHub Issue Input

If user provides a GitHub issue (e.g., `/orchestrate gh issue #17` or `/orchestrate #17`):

1. **Extract issue number**: Parse issue number from input
2. **Pass to Scout**: Scout reads issue via `gh issue view #[number]`
3. **Pass to Cleanup**: Cleanup updates issue with results
4. **Cleanup closes issue**: Only if work is 100% complete and verified
5. **Create related issues**: For significant future work detected (>4 hours)
6. **Report in final output**: Note issue status and links

### Phased Work

If Plan agent detects work is too large and recommends phasing:

1. **Report to user**: "⚠️ Plan Agent recommends phasing this work"
2. **Show phases**: Display phase breakdown from plan-output.md
3. **Ask user**: "Proceed with Phase 1 only? (yes/no)"
4. **If yes**: Continue with Build/Test/Cleanup for Phase 1 only
5. **If no**: Stop and wait for user decision

### Blocker Scenarios

If any agent encounters a blocker:

1. **Report immediately**: "⚠️ [Agent] encountered blocker: [description]"
2. **Show blocker details**: From agent's output
3. **Continue if possible**: Other agents may still proceed
4. **Final report shows blockers**: Clearly documented in completion report

## GitHub Issue Progress Updates

When processing a GitHub issue (`/orchestrate gh issue #N`), post brief progress comments after each agent completes:

1. **🔍 Scout**: What was discovered about the issue (2-3 sentences)
2. **📋 Plan**: Number of tasks, estimated effort, key changes
3. **🔨 Build**: What was implemented, files created/modified, build status
4. **🧪 Test**: Test results, coverage, any fixes made
5. **🧹 Cleanup**: Completion report location, future work detected, commit info

**Benefits**:
- Real-time visibility into 30+ minute workflows
- GitHub issue becomes a live log of progress
- No need to wait for completion to see status
- Team can track workflow progress without access to Claude Code output

## Critical Rules

1. **🚨 ORCHESTRATION ONLY - NO DIRECT WORK 🚨**:
   - You are a CONDUCTOR, not a performer
   - Your ONLY allowed tools during `/orchestrate` are: Task (to call agents) and Read (ONLY to read agent output files)
   - If you use Read, Write, Edit, Grep, Glob, or Bash on any file except agent outputs, YOU ARE VIOLATING THE CORE PURPOSE OF THIS COMMAND
   - All investigation, implementation, testing, and documentation MUST be done by agents via the Task tool
   - "But I just need to quickly check..." = NO. Call an agent.
   - "But this is a simple fix..." = NO. Call an agent.
   - "But I can see the issue right here..." = NO. Call an agent.

2. **SEQUENTIAL EXECUTION**: Each agent must complete before next starts

3. **REPORT PROGRESS**: Update user on each agent's start/completion

4. **PASS CONTEXT**: Each agent gets exactly what it needs from previous agents

5. **HANDLE SPEC FILES**: Update and move spec files when provided

6. **DETECT FUTURE WORK**: Ensure Cleanup creates specs for significant issues

7. **VERIFY OUTPUTS**: Check each agent created its output file before proceeding

8. **FINAL REPORT**: Always provide comprehensive summary at end

## Success Criteria

- ✅ All 5 agents executed successfully
- ✅ All output files created (.agents/outputs/)
- ✅ Completion report in completion-docs/
- ✅ Future work specs created (if issues found)
- ✅ Spec file updated and moved (if provided)
- ✅ GitHub issue updated with results (if provided)
- ✅ GitHub issue closed if appropriate (if provided and work complete)
- ✅ Related GitHub issues created for future work (if significant issues found)
- ✅ Git committed and pushed
- ✅ User receives clear final report
- ✅ Workflow stopped, awaiting user review

## Example Usage

```bash
# Feature from spec file
/orchestrate @specs/feature-client-codes-crud.md

# Bug fix from GitHub issue
/orchestrate gh issue #17
/orchestrate #17

# Bug fix from description
/orchestrate Fix null pointer error in TravelController when user has no department

# Feature from plain text
/orchestrate Add dark mode toggle to user settings page with persistence

# Multiple related items
/orchestrate Implement expense categories CRUD, add category filter to reports, update category seeder
```

## Notes

- This command is the primary entry point for all significant work
- Replaces manual agent calling for standardized workflow
- Ensures all steps are followed consistently
- Automatically handles spec file lifecycle
- Detects and documents future work needs
- Provides clear handoff to user at completion
